from airflow.models import BaseOperator
from airflow.utils.context import Context
from airflow.exceptions import AirflowException
from globalscape_plugin.eft_hook import GlobalscapeEFTHook
import time


class GlobalscapeEFTOperator(BaseOperator):

    template_fields = ("event_rule", "event_params", "timeout")

    def __init__(
        self,
        *,
        event_rule: str,
        event_params: str | None = None,
        conn_id: str,
        timeout: int | None = None,   
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.event_rule = event_rule
        self.event_params = event_params
        self.conn_id = conn_id
        self.timeout = timeout

    def execute(self, context: Context):

        start_time = time.time()

        self.log.info("======================================")
        self.log.info("Starting Globalscape EFT Execution")
        self.log.info("Event Rule      : %s", self.event_rule)
        self.log.info("Event Parameters: %s", self.event_params)
        self.log.info("Timeout(sec)    : %s", self.timeout)
        self.log.info("======================================")

        hook = GlobalscapeEFTHook(conn_id=self.conn_id)

       
        effective_timeout = self.timeout if self.timeout else 3600

        result = hook.trigger_event_rule(
            event_rule=self.event_rule,
            event_params=self.event_params,
            timeout=effective_timeout,
        )

        duration = round(time.time() - start_time, 2)

        self.log.info("----------- EFT RESPONSE -----------")
        self.log.info("HTTP Status  : %s", result.get("status_code"))
        self.log.info("Status       : %s", result.get("status"))
        self.log.info("Duration(sec): %s", duration)

        self.log.info("----------- FULL EFT XML RESPONSE -----------")
        self.log.info("\n%s\n", result.get("response_body"))
        self.log.info("---------------------------------------------")

        context["ti"].xcom_push(
            key="eft_result",
            value=result
        )

        if result.get("status") != "SUCCESS":
            raise AirflowException(
                f"EFT execution failed: {result.get('error')}"
            )

        self.log.info("EFT execution successful.")
        self.log.info("======================================")

        return None