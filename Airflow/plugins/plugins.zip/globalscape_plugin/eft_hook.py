import json
import boto3
import requests
from urllib.parse import quote
from airflow.hooks.base import BaseHook
from airflow.models import Variable
from airflow.exceptions import AirflowException


class GlobalscapeEFTHook:

    def __init__(self, conn_id: str):
        self.conn_id = conn_id
        self.secret_arn = Variable.get("GLOBALSCAPE_USER_ARN")
        self.region_name = Variable.get("GLOBALSCAPE_AWS_REGION")

    def _get_secret(self) -> dict:
        try:
            client = boto3.client("secretsmanager", region_name=self.region_name)
            response = client.get_secret_value(SecretId=self.secret_arn)
            return json.loads(response["SecretString"])
        except Exception as exc:
            raise AirflowException(f"Failed to retrieve secret: {str(exc)}")

    def _get_connection_host(self) -> str:
        conn = BaseHook.get_connection(self.conn_id)
        if not conn.host:
            raise AirflowException("Connection host is not defined.")
        return conn.host.rstrip("/")

    def trigger_event_rule(
        self,
        event_rule: str,
        event_params: str | None = None,
        timeout: int | float | str | None = 3600,
    ) -> dict:

        base_url = self._get_connection_host()
        secret = self._get_secret()

        username = secret.get("username")
        password = secret.get("password")

        if not username or not password:
            raise AirflowException("Invalid secret structure.")

        # -----------------------------------------
        # EFT requires EventParams key always
        # -----------------------------------------
        if event_params is None:
            event_params = ""

        # Encode only EventRuleName
        encoded_event_rule = quote(event_rule, safe="")

        api_url = (
            f"{base_url}/WebService/InvokeEventRule"
            f"?EventRuleName={encoded_event_rule}"
            f"&EventParams={event_params}"
        )

        # -----------------------------------------
        # Validate and cast timeout safely
        # -----------------------------------------
        if timeout is None:
            timeout = 3600

        try:
            timeout = float(timeout)
        except (TypeError, ValueError):
            raise AirflowException(f"Invalid timeout value: {timeout}")

        # -----------------------------------------
        # Execute Request
        # -----------------------------------------
        try:
            response = requests.get(
                api_url,
                auth=(username, password),
                timeout=timeout,
                verify=True,
            )
        except requests.RequestException as exc:
            raise AirflowException(f"EFT request failed: {str(exc)}")

        body = response.text or ""

        result = {
            "status_code": response.status_code,
            "reason": response.reason,
            "status": None,
            "response_body": body,
            "error": None,
        }

        # -----------------------------------------
        # HTTP-level validation
        # -----------------------------------------
        if response.status_code != 200:
            result["status"] = "FAILED"
            result["error"] = "HTTP_ERROR"
            return result

        # -----------------------------------------
        # EFT ResultCode parsing
        # -----------------------------------------
        if "<ResultCode>1</ResultCode>" in body:
            result["status"] = "SUCCESS"
        elif "<ResultCode>0</ResultCode>" in body:
            result["status"] = "FAILED"
            result["error"] = "EXECUTION_FAILED"
        elif "-1</int>" in body:
            result["status"] = "FAILED"
            result["error"] = "RULE_NOT_FOUND"
        else:
            result["status"] = "FAILED"
            result["error"] = "UNKNOWN_RESPONSE"

        return result