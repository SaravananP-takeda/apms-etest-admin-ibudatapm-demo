from airflow.plugins_manager import AirflowPlugin

class GlobalscapeEFTPlugin(AirflowPlugin):
    name = "globalscape_eft_plugin"