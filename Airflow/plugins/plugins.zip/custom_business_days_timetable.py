from airflow.timetables.base import Timetable, DagRunInfo, DataInterval
from airflow.models import Variable
import pendulum
from typing import Optional, Set


def _load_holidays_from_variable() -> Set[str]:
    """
    Load holidays from Airflow Variable `holiday_dates`.
    Supports JSON list or newline-separated string.
    """
    holidays = set()
    try:
        raw = Variable.get("holiday_dates", default_var="")

        # Try JSON decode first
        try:
            import json
            parsed = json.loads(raw)
            if isinstance(parsed, list):
                holidays = {str(h).strip() for h in parsed}
            else:
                holidays = {str(parsed).strip()}
        except Exception:
            # Fallback: newline/comma-separated text
            for line in raw.splitlines():
                line = line.strip()
                if line:
                    holidays.add(line)
    except Exception as e:
        # If variable not found or other errors, return empty set
        print(f"[BusinessDaysTimetableCustom] Could not load Variable 'holiday_dates': {e}")
        holidays = set()

    return holidays


class BusinessDaysTimetableCustom(Timetable):
    """
    Custom timetable that skips weekends and holidays
    (holidays loaded from Airflow Variable `holiday_dates`).
    """

    def __init__(self, holidays: Optional[Set[str]] = None):
        # Lazy-load holidays if not provided
        self.holidays = holidays or _load_holidays_from_variable()

    def next_dagrun_info(
        self,
        last_automated_data_interval: Optional[DataInterval],
        restriction,
    ) -> Optional[DagRunInfo]:
        if last_automated_data_interval:
            next_run = last_automated_data_interval.end
        elif getattr(restriction, "earliest", None):
            next_run = restriction.earliest
        else:
            next_run = pendulum.today("UTC")

        # Skip weekends and holidays
        while next_run.weekday() >= 5 or next_run.date().isoformat() in self.holidays:
            next_run = next_run.add(days=1)

        return DagRunInfo.exact(next_run)

    def infer_manual_data_interval(self, run_after: pendulum.DateTime):
        return pendulum.period(run_after, run_after)
