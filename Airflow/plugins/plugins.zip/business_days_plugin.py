from airflow.plugins_manager import AirflowPlugin

try:
    from custom_business_days_timetable import BusinessDaysTimetableCustom
except Exception as e:
    BusinessDaysTimetableCustom = None
    print(f"[BusinessDaysPlugin] Failed to import timetable: {e}")

class BusinessDaysTimetablePlugin(AirflowPlugin):
    name = "business_days_timetable_plugin"
    timetables = [BusinessDaysTimetableCustom] if BusinessDaysTimetableCustom else []
