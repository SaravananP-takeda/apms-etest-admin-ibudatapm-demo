from airflow.providers.ssh.hooks.ssh import SSHHook
from airflow.models import Variable
from airflow.exceptions import AirflowException
import logging
import random
import time
import json
import ast


class IICSSSHFailoverHook:

    def __init__(
        self,
        ssh_conn_ids: list = None,
        job_script_path: str = None,
        timeout: int = 20700
    ):
        self.log = logging.getLogger(__name__)
        self.timeout = timeout


        try:
            self.job_script_path = (
                job_script_path
                if job_script_path
                else Variable.get("IICS_JOB_SCRIPT_PATH")
            )
        except KeyError:
            raise AirflowException(
                "Airflow Variable 'IICS_JOB_SCRIPT_PATH' is not defined."
            )


        try:
            if ssh_conn_ids:
                self.ssh_conn_ids = ssh_conn_ids
            else:
                raw_value = Variable.get("IICS_SSH_CONN_IDS")

                try:
                    # Preferred: valid JSON
                    self.ssh_conn_ids = json.loads(raw_value)
                except json.JSONDecodeError:
                    # Fallback: Python-style list
                    self.log.warning(
                        "IICS_SSH_CONN_IDS is not valid JSON. Falling back to ast parsing."
                    )
                    self.ssh_conn_ids = ast.literal_eval(raw_value)

        except KeyError:
            raise AirflowException(
                "Airflow Variable 'IICS_SSH_CONN_IDS' is not defined."
            )
        except Exception as e:
            raise AirflowException(
                f"Error parsing 'IICS_SSH_CONN_IDS': {str(e)}"
            )


        if not isinstance(self.ssh_conn_ids, list) or not self.ssh_conn_ids:
            raise AirflowException(
                "IICS_SSH_CONN_IDS must be a non-empty list."
            )

    def run_job(self, job_args: str, context):

        command = f"{self.job_script_path} {job_args}"

        self.log.info(f"Executing command: {command}")
        self.log.info(f"Configured timeout: {self.timeout} seconds")

        random.shuffle(self.ssh_conn_ids)
        self.log.info(f"Host failover order: {self.ssh_conn_ids}")

        last_exception = None
        start_time = time.time()

        for conn_id in self.ssh_conn_ids:
            try:
                self.log.info(f"Attempting SSH connection: {conn_id}")

                hook = SSHHook(ssh_conn_id=conn_id)
                ssh_client = hook.get_conn()

                stdin, stdout, stderr = ssh_client.exec_command(
                    command,
                    timeout=self.timeout
                )

                exit_code = stdout.channel.recv_exit_status()

                output = stdout.read().decode().strip()
                error = stderr.read().decode().strip()

                # --------------------------------------------------
                # Log STDOUT
                # --------------------------------------------------
                if output:
                    self.log.info("----- IICS JOB STDOUT START -----")
                    for line in output.splitlines():
                        self.log.info(line)
                    self.log.info("----- IICS JOB STDOUT END -----")

                # --------------------------------------------------
                # Log STDERR
                # --------------------------------------------------
                if error:
                    self.log.warning("----- IICS JOB STDERR START -----")
                    for line in error.splitlines():
                        self.log.warning(line)
                    self.log.warning("----- IICS JOB STDERR END -----")

                # --------------------------------------------------
                # Push XCom values
                # --------------------------------------------------
                context["ti"].xcom_push(key="job_output", value=output)
                context["ti"].xcom_push(key="job_error", value=error)
                context["ti"].xcom_push(key="exit_code", value=exit_code)

                # --------------------------------------------------
                # Exit Code Handling
                # --------------------------------------------------
                if exit_code != 0:
                    raise AirflowException(
                        f"IICS job failed on {conn_id} with exit code {exit_code}"
                    )

                duration = round(time.time() - start_time, 2)
                self.log.info(
                    f"IICS job succeeded on {conn_id} "
                    f"(Execution time: {duration} seconds)"
                )

                return output

            except Exception as e:
                self.log.warning(
                    f"Execution failed on host {conn_id}: {str(e)}"
                )
                last_exception = e

                # Failover only for connection-related issues
                if any(msg in str(e) for msg in [
                    "Unable to connect",
                    "timed out",
                    "NoValidConnectionsError",
                    "Error reading SSH protocol banner"
                ]):
                    self.log.info("Failing over to next host...")
                    continue
                else:
                    raise

        # --------------------------------------------------
        # All Hosts Failed
        # --------------------------------------------------
        raise AirflowException(
            f"All SSH hosts failed. Last error: {str(last_exception)}"
        )