from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults
from airflow.plugins_manager import AirflowPlugin
from iics_plugin.iics_hook import IICSSSHFailoverHook


class IICSRunJobOperator(BaseOperator):

    template_fields = ("job_args",)

    DEFAULT_TIMEOUT = 20700

    @apply_defaults
    def __init__(
        self,
        job_args: str,
        ssh_conn_ids: list = None,
        job_script_path: str = None,
        timeout: int = None,
        **kwargs
    ):
        super().__init__(**kwargs)

        self.job_args = job_args
        self.ssh_conn_ids = ssh_conn_ids
        self.job_script_path = job_script_path

        # If timeout not provided, use default
        self.timeout = timeout if timeout is not None else self.DEFAULT_TIMEOUT

    def execute(self, context):

        hook = IICSSSHFailoverHook(
            ssh_conn_ids=self.ssh_conn_ids,
            job_script_path=self.job_script_path,
            timeout=self.timeout
        )

        return hook.run_job(self.job_args, context)
