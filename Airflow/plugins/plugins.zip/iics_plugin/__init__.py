from airflow.plugins_manager import AirflowPlugin
from iics_plugin.iics_operator import IICSRunJobOperator


class IICSPlugin(AirflowPlugin):
    name = "iics_plugin"
    operators = [IICSRunJobOperator]